package com.madesocial.item;


public class ItemAbout {

    private String appName;
    private String appLogo;
    private String appVersion;
    private String appAuthor;
    private String appContact;
    private String appEmail;
    private String appWebsite;
    private String appDescription;
    private String appPrivacy;
    private String appDevelop;
    private String appTagline;
    private String appBannerId;
    private String appFullId;
    private String appBannerOn;
    private String appFullOn;
    private String appFullPub;
    private String appFullAdsClick;



    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppLogo() {
        return appLogo;
    }

    public void setAppLogo(String appLogo) {
        this.appLogo = appLogo;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getAppAuthor() {
        return appAuthor;
    }

    public void setAppAuthor(String appAuthor) {
        this.appAuthor = appAuthor;
    }

    public String getAppContact() {
        return appContact;
    }

    public void setAppContact(String appContact) {
        this.appContact = appContact;
    }

    public String getAppEmail() {
        return appEmail;
    }

    public void setAppEmail(String appEmail) {
        this.appEmail = appEmail;
    }

    public String getAppWebsite() {
        return appWebsite;
    }

    public void setAppWebsite(String appWebsite) {
        this.appWebsite = appWebsite;
    }

    public String getAppDescription() {
        return appDescription;
    }
     public void setAppDescription(String appDescription) {
        this.appDescription = appDescription;
    }

    public String getappPrivacy() {
        return appPrivacy;
    }
    public void setappPrivacy(String appPrivacy) {
        this.appPrivacy = appPrivacy;
    }

    public String getappDevelop() {
        return appDevelop;
    }
    public void setappDevelop(String appDevelop) {
        this.appDevelop = appDevelop;
    }

    public String getappTagline() {
        return appTagline;
    }
    public void setappTagline(String appTagline) {
        this.appTagline = appTagline;
    }

    public String getappFullPub() {
        return appFullPub;
    }
    public void setappFullPub(String appFullPub) {
        this.appFullPub = appFullPub;
    }
    public String getappBannerId() {
        return appBannerId;
    }
    public void setappBannerId(String appBannerId) {
        this.appBannerId = appBannerId;
    }

    public String getappFullId() {
        return appFullId;
    }
    public void setappFullId(String appFullId) {
        this.appFullId = appFullId;
    }

    public String getappBannerOn() {
        return appBannerOn;
    }
    public void setappBannerOn(String appBannerOn) {
        this.appBannerOn = appBannerOn;
    }

    public String getappFullOn() {
        return appFullOn;
    }
    public void setappFullOn(String appFullOn) {
        this.appFullOn = appFullOn;
    }

    public String getappFullAdsClick() {
        return appFullAdsClick;
    }
    public void setappFullAdsClick(String appFullAdsClick) {
        this.appFullAdsClick = appFullAdsClick;
    }
}
