package com.madesocial.util;

import android.content.Context;
import android.widget.TextView;
import android.widget.Toast;

import me.saket.bettermovementmethod.BetterLinkMovementMethod;

public class GeneralUtils {
    public void addBetterLinkMovementToTextView(final Context context, TextView textView) {
        BetterLinkMovementMethod betterLinkMovementMethod = BetterLinkMovementMethod.newInstance();
        betterLinkMovementMethod.setOnLinkClickListener(new BetterLinkMovementMethod.OnLinkClickListener() {
            @Override
            public boolean onClick(TextView textView, String url) {
                //navigate to web view fragment
                Toast.makeText(context, "Link clicked", Toast.LENGTH_SHORT).show();
                return true;
            }
        });
    }
}
